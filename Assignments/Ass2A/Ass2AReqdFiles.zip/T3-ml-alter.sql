--****PLEASE ENTER YOUR DETAILS BELOW****
--T3-ml-alter.sql

--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/

-- 3 (a)





-- 3 (b)





-- 3 (c)



