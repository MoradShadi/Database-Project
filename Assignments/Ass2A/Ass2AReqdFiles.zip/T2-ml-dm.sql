--****PLEASE ENTER YOUR DETAILS BELOW****
--T2-ml-dm.sql

--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/

-- 2 (b) (i)






-- 2 (b) (ii)






-- 2 (b) (iii)






-- 2 (b) (iv)

