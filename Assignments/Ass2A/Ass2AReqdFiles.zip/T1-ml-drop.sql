--****PLEASE ENTER YOUR DETAILS BELOW****
--T1-ml-drop.sql

--Student ID:
--Student Name:
--Tutorial No:

/* Comments for your marker:




*/

-- 1.2 Add Drop table statements for ALL table below (not just those created
-- in this script)use ONLY
--      DROP TABLE tblname PURGE
-- syntax DO NOT use CASCADE CONSTRAINTS



